﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PruebaTecnica.Model.Configuration
{
    public class SwaggerEndpoint
    {
        public string Name { get; set; }
        public string Url { get; set; }
    }
}
