﻿using System;

namespace PruebaTecnica.Model
{
    public class Marca
    {
        public int IdMarca { get; set; }

        public bool Descripcion { get; set; }
    }
}
