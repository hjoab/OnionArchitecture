﻿using Microsoft.Extensions.DependencyInjection;
using PruebaTecnica.DataAccess.Interface;


namespace PruebaTecnica.DataAccess
{ 
    public static class DependencyInjectionDA
    {
        public static void InjectData(this IServiceCollection service)
        {
            service.AddScoped<IArticuloMarcaDA, ArticuloMarcaDA>();

            service.AddScoped<IConnectionManager, ConnectionManager>();
        }
    }
}