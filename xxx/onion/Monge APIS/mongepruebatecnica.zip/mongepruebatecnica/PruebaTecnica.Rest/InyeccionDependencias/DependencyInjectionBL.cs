﻿
using Microsoft.Extensions.DependencyInjection;
using PruebaTecnica.BusinessLogic.Interface;


namespace PruebaTecnica.BusinessLogic
{
    public static class DependencyInjectionBL
    {
        public static void InjectLogic(this IServiceCollection service)
        {
            service.AddScoped<IArticuloMarcaBL, ArticuloMarcaBL>();
        }       
    }
}
