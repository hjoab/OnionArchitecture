﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using Microsoft.OpenApi.Models;
using PruebaTecnica.Model.Configuration;
using Microsoft.AspNetCore.Authentication.AzureAD.UI;
using Microsoft.AspNetCore.Authentication;


using PruebaTecnica.BusinessLogic;
using PruebaTecnica.DataAccess;

namespace PruebaTecnica.Rest
{
    public static class IocExtension
    {
        public static void IocInjectAllDependencies(this IServiceCollection iserviceCollection, IConfiguration Configuration)
        {
            SwaggerConfiguration swaggerConfiguration = new Model.Configuration.SwaggerConfiguration();
            Configuration.Bind("SwaggerConfiguration", swaggerConfiguration);
            iserviceCollection.AddSingleton(swaggerConfiguration);

            AzureADOptions azureAdOptions = new AzureADOptions();
            Configuration.Bind("AzureAd", azureAdOptions);
            iserviceCollection.AddSingleton(azureAdOptions);

            iserviceCollection.AddAuthentication(AzureADDefaults.BearerAuthenticationScheme)
                .AddAzureADBearer(options => Configuration.Bind("AzureAd", options));

            iserviceCollection.AddControllers();

            iserviceCollection.AddSwaggerGen(options =>
            {
                options.IgnoreObsoleteActions();
                options.IgnoreObsoleteProperties();
                options.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = "v1",
                    Title = $"PruebaTI.Service - Environment: {Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")}",
                    Description = "Componentes Prueba",
                    TermsOfService = new Uri("http://www.grupomonge.com"),
                    Contact = new OpenApiContact()
                    {
                        Name = "Tecnologías de la información",
                        Url = new Uri("http://www.grupomonge.com")
                    },
                    License = new OpenApiLicense
                    {
                        Name = "GrupoMonge©",
                        Url = new Uri("http://www.grupomonge.com")
                    },
                });


                options.AddSecurityDefinition("Azure Active Directory", new OpenApiSecurityScheme
                {
                    Type = SecuritySchemeType.OAuth2,
                    Flows = new OpenApiOAuthFlows
                    {
                        Implicit = new OpenApiOAuthFlow
                        {
                            AuthorizationUrl = new Uri($"{Configuration["AzureAd:Instance"]}{Configuration["AzureAd:TenantId"]}/oauth2/authorize", UriKind.Absolute),
                            Scopes = new Dictionary<string, string> { { "user_impersonation", "Access API" } }
                        }
                    }
                });
                options.AddSecurityRequirement(new OpenApiSecurityRequirement()
                    {
                        {
                            new OpenApiSecurityScheme
                            {
                                Reference = new OpenApiReference
                                {
                                    Type = ReferenceType.SecurityScheme,
                                    Id = "Azure Active Directory"
                                },
                                Scheme = "oauth2",
                                Name = "Bearer",
                                In = ParameterLocation.Header,
                            },
                             new List<string>()
                        }
                    });
                options.IncludeXmlComments(System.IO.Path.Combine(AppContext.BaseDirectory, $"{System.Reflection.Assembly.GetExecutingAssembly().GetName().Name}.xml"));
            });
        }
    }
}
