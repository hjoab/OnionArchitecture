using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Authentication.AzureAD.UI;



using PruebaTecnica.BusinessLogic;
using PruebaTecnica.DataAccess;
using Swashbuckle.AspNetCore.SwaggerGen;
using PruebaTecnica.Model.Configuration;

namespace PruebaTecnica.Rest
{
    public class Startup
    {
        public IConfiguration Configuration { get; }

        public Startup(IConfiguration configuration)
        {
            this.Configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            //services.IocInjectAllDependencies(Configuration); hjoab

            #region hjoab1
            services.AddControllers();

            services.InjectLogic();
            services.InjectData();


            #region Swagger
            services.AddSwaggerGen(c =>
            {
                c.IncludeXmlComments(string.Format(@"{0}\PruebaTecnica.Rest.xml", System.AppDomain.CurrentDomain.BaseDirectory));
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = "v1",
                    Title = "PruebaTecnica.Rest",
                });

            });
            #endregion

            #region Api Versioning
            // Add API Versioning to the Project
            services.AddApiVersioning(config =>
            {
                    // Specify the default API Version as 1.0
                    config.DefaultApiVersion = new ApiVersion(1, 0);
                    // If the client hasn't specified the API version in the request, use the default API version number 
                    config.AssumeDefaultVersionWhenUnspecified = true;
                    // Advertise the API versions supported for the particular endpoint
                    config.ReportApiVersions = true;
            });
            #endregion


          
            
            #endregion hjoab1
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        // public void Configure(ApplicationBuilder app, IWebHostEnvironment env, Model.Configuration.SwaggerConfiguration swaggerConfiguration, AzureADOptions azureAdOptions)

        #region hjoab2 
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        #endregion hjoab2

        {

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            #region hjoab3.1
            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseAuthorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
            #endregion hjoab3.1

            //app.UseStaticFiles();
            //app.UseRouting();
            //app.UseCors();
            //app.UseSession();//add this sesstion function here
            //app.UseAuthentication();
            //app.UseAuthorization();
            //app.UseHttpsRedirection();
            //app.UseDefaultFiles();
            //app.UseEndpoints(endpoints => endpoints.MapControllers());

            //// var swaggerConfiguration = new Model.Configuration.SwaggerConfiguration();
            // app.UseSwagger();
            // app.UseSwaggerUI(options =>
            // {
            //     options.OAuthClientId(swaggerConfiguration.ClientId);
            //     options.OAuthClientSecret(swaggerConfiguration.ClientSecret);
            //     options.OAuthRealm(azureAdOptions.ClientId);
            //     options.OAuthAppName("Gmg.Monedero.Catalogo.Service");
            //     options.OAuthScopeSeparator(" ");
            //     options.OAuthAdditionalQueryStringParams(new Dictionary<string, string> { { "resource", azureAdOptions.ClientId } });
            //     foreach (var endpoint in swaggerConfiguration.Endpoints)
            //     {
            //         options.SwaggerEndpoint(endpoint.Url, endpoint.Name);
            //     }
            // });

            #region hjoab3.2

            #region Swagger
             // Enable middleware to serve generated Swagger as a JSON endpoint.
             app.UseSwagger();
            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.),
            // specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "PruebaTecnica.Rest");
            });
            #endregion 

            #endregion hjoab3.2

            //app.MapApiKey();
        }
    }
}
