﻿using PruebaTecnicaFrontEnd.Models;

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web.Mvc;


namespace PruebaTecnicaFrontEnd.Controllers
{
    //public class HomeController : Controller
    //{
    //    //ArticuloController articuloController = new ArticuloController();

    //    [HttpGet]
    //    public ActionResult Index()
    //    {
    //        //RedirectToAction("Listar", "Articulo");
    //        return View();
    //    }

    //}

    public class HomeController : Controller
    {
        string Baseurl = "http://localhost:34567/";
        //string Baseurl = "http://localhost:44340/";  // Onion
        string Baseurlssl = "http://localhost:443333";
        string Endpoint = "api/v1.0/Articulo/Listar";

        // GET: Articulo
        public async Task<ActionResult> Index()
        {
            List<Articulo> articulos = new List<Articulo>();

            using (var client = new HttpClient())
            {
                //Passing service base url
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();
                //Define request data format
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Sending request to find web api REST service resource using HttpClient
                HttpResponseMessage msg = await client.GetAsync(Endpoint);

                //Checking the response is successful or not which is sent using HttpClient
                if (msg.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api 
                    var resp = msg.Content.ReadAsStringAsync().Result;

                    //Deserializing the response recieved from web api and storing into the list
                    articulos = JsonConvert.DeserializeObject<List<Articulo>>(resp);

                }
                //returning the employee list to view
                return View(articulos);
            }
        }
    }
}