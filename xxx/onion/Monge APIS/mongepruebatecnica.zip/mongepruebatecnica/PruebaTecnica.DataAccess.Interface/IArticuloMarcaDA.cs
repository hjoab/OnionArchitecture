﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PruebaTecnica.DataAccess.Interface
{
    public interface IArticuloMarcaDA
    {
        IEnumerable<Model.ArticuloMarca> Listar();
    }
}
