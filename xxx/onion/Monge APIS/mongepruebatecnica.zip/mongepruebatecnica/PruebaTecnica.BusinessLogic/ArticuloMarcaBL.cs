﻿using Microsoft.Extensions.Configuration;
using PruebaTecnica.BusinessLogic.Interface;
using System;
using System.Collections.Generic;

namespace PruebaTecnica.BusinessLogic
{
    public class ArticuloMarcaBL : Interface.IArticuloMarcaBL
    {
        #region Atributos
        private readonly DataAccess.Interface.IArticuloMarcaDA articuloDataAccess;

        #endregion

        public ArticuloMarcaBL(DataAccess.Interface.IArticuloMarcaDA articuloDataAccess)
        {
            this.articuloDataAccess = articuloDataAccess;
        }

        public IEnumerable<Model.ArticuloMarca> Listar()
        {
            return articuloDataAccess.Listar();
        }

     
    }
}
