﻿using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace PruebaTecnica.DataAccess
{
    public class ArticuloMarcaDA : Interface.IArticuloMarcaDA
    {
        #region Atributos
        private readonly Interface.IConnectionManager connectionManager;
        #endregion

        public ArticuloMarcaDA(DataAccess.Interface.IConnectionManager connectionManager)
        {
            this.connectionManager = connectionManager;
        }

        public IEnumerable<Model.ArticuloMarca> Listar()
        {
            var cn = connectionManager.CreateConnection(ConnectionManager.Prueba_Key);
            using (cn)
            {

                var resultado = cn.Query<Model.ArticuloMarca>(
                    sql: "usp_ConsultaArticulos", 
                    commandType: System.Data.CommandType.StoredProcedure);
                //var resultado = cn.Query<Model.ArticuloMarca>(
                //    "usp_ConsultaArticulos", new Model.ArticuloMarca(),
                //    commandType: System.Data.CommandType.StoredProcedure);

                return resultado;
            }
        }
    }
}
