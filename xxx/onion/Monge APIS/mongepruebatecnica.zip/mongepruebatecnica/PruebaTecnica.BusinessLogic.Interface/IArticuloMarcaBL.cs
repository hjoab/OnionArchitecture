﻿using System.Collections.Generic;

namespace PruebaTecnica.BusinessLogic.Interface
{
    public interface IArticuloMarcaBL
    {
        public IEnumerable<Model.ArticuloMarca> Listar();
    }
}
