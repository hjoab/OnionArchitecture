﻿using System;

namespace Domain.Entities
{
    public class Marca
    {
        public int IdMarca { get; set; }

        public bool Descripcion { get; set; }
    }
}
